// View Image in Modal
function viewGalleryItem(imageSrc, eventName, eventDate) {
    document.getElementById("modalImage").src = imageSrc;
    document.getElementById("modalTitle").innerText = eventName;
    document.getElementById("modalDate").innerText = eventDate;
    
    document.getElementById("imageViewModal").style.display = "flex";
}

// Close Modal
function closeModal() {
    document.getElementById("imageViewModal").style.display = "none";
}

// Close modal on background click
window.onclick = function(event) {
    if (event.target === document.getElementById("imageViewModal")) {
        closeModal();
    }
};
