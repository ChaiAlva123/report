<?php
include '../db.php';

// Fetch all gallery data
$sql = "SELECT id, event_name, event_date, image FROM gallery";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - User</title>
    <link rel="stylesheet" href="gallery.css"> <!-- Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="script.js" defer></script> <!-- External JS file -->
</head>
<body>
    <main class="main-content">
        <?php include '../sidebar.php';?>
        <header>
            <div class="header-content">
                <h1>Event Gallery</h1>
                <!-- Date Filter -->
                <input type="date" id="dateFilter" onchange="filterByDate()">
            </div>
        </header>

        <div class="gallery-grid" id="galleryContainer">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $imageSrc = "data:image/jpeg;base64," . base64_encode($row['image']);
                    $eventName = htmlspecialchars($row['event_name'], ENT_QUOTES, 'UTF-8');
                    $eventDate = date("Y-m-d", strtotime($row['event_date'])); // Format for filtering
                    $eventDisplayDate = date("F d, Y", strtotime($row['event_date'])); // Display format

                    echo '<div class="gallery-item" data-date="' . $eventDate . '">
                            <img src="' . $imageSrc . '" alt="' . $eventName . '" onclick="viewGalleryItem(\'' . $imageSrc . '\', \'' . addslashes($eventName) . '\', \'' . $eventDisplayDate . '\')">
                            <div class="gallery-info">
                                <h4>' . $eventName . '</h4>
                                <p>' . $eventDisplayDate . '</p>
                                <button class="view-btn" onclick="viewGalleryItem(\'' . $imageSrc . '\', \'' . addslashes($eventName) . '\', \'' . $eventDisplayDate . '\')">
                                    <i class="fas fa-expand"></i> View
                                </button>
                            </div>
                          </div>';
                }
            } else {
                echo "<p class='no-images'>No gallery images available.</p>";
            }
            $conn->close();
            ?>
        </div>
    </main>

    <!-- Image View Modal -->
    <div id="imageViewModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <img id="modalImage" src="" alt="Full size image">
            <div class="image-info">
                <h3 id="modalTitle"></h3>
                <p id="modalDate"></p>
            </div>
        </div>
    </div>

    <script>
        function filterByDate() {
            let selectedDate = document.getElementById("dateFilter").value;
            let items = document.querySelectorAll(".gallery-item");

            items.forEach(item => {
                let eventDate = item.getAttribute("data-date");

                if (selectedDate === "" || eventDate === selectedDate) {
                    item.style.display = "block";
                } else {
                    item.style.display = "none";
                }
            });
        }
    </script>
</body>
</html>
 