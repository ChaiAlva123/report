<?php
include '../db.php';

$query = "SELECT id, title, date, location, total_spots, remaining_spots, image FROM `add-event`";
$result = $conn->query($query);

$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
</head>
<body>
    <main class="main-content">
        <?php include '../sidebar.php'; ?>
        <header>
            <div class="header-content">
                <h1>Upcoming Events</h1>
                <div class="view-toggle">
                    <button id="gridViewBtn" class="active"><i class="fas fa-th"></i> Grid</button>
                    <button id="calendarViewBtn"><i class="fas fa-calendar-alt"></i> Calendar</button>
                </div>
            </div>
        </header>

        <!-- Grid View -->
        <div class="events-grid">
            <?php foreach ($events as $event): ?>
                <div class="event-card">
                    <img src="data:image/jpeg;base64,<?= base64_encode($event['image']) ?>" alt="Event">
                    <div class="event-info">
                        <h3><?= $event['title'] ?></h3>
                        <p class="date"><i class="fas fa-calendar"></i> <?= date("F d, Y", strtotime($event['date'])) ?></p>
                        <p class="location"><i class="fas fa-map-marker-alt"></i> <?= $event['location'] ?></p>
                        <p class="spots"><i class="fas fa-user-friends"></i> <?= $event['remaining_spots'] ?> spots left</p>
                        <button class="register-btn" onclick="registerForEvent(<?= $event['id'] ?>)">Register Now</button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Calendar View -->
        <div class="events-calendar" style="display: none;">
            <div id="calendar"></div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <script src="script.js"></script>
</body>
</html>
