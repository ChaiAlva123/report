<?php
include '../db.php';

header('Content-Type: application/json'); // Ensure JSON response

$query = "SELECT id, title, date FROM `add-event`";
$result = $conn->query($query);

$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = [
        'id' => $row['id'],
        'title' => $row['title'],
        'date' => date("Y-m-d", strtotime($row['date'])) // Format date correctly
    ];
}

echo json_encode($events);
?>
