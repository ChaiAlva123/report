document.addEventListener('DOMContentLoaded', function () {
    let calendarEl = document.getElementById('calendar');
    let gridView = document.querySelector('.events-grid');
    let calendarView = document.querySelector('.events-calendar');
    let gridViewBtn = document.getElementById('gridViewBtn');
    let calendarViewBtn = document.getElementById('calendarViewBtn');
    let calendar; // Declare calendar globally

    // Toggle Views
    gridViewBtn.addEventListener('click', function () {
        gridView.style.display = 'grid';
        calendarView.style.display = 'none';
        gridViewBtn.classList.add('active');
        calendarViewBtn.classList.remove('active');
    });

    calendarViewBtn.addEventListener('click', function () {
        gridView.style.display = 'none';
        calendarView.style.display = 'block';
        if (calendar) {
            calendar.render(); // Ensure the calendar is rendered properly
        }
        calendarViewBtn.classList.add('active');
        gridViewBtn.classList.remove('active');
    });

    // Fetch Events and Initialize Calendar
    fetch("fetch-events.php")
        .then(response => response.json())
        .then(events => {
            console.log("Fetched Events:", events); // Debugging: Check if events are loaded correctly

            if (!Array.isArray(events)) {
                console.error("Error: Events data is not an array!");
                return;
            }

            // Convert dates to ISO 8601 format if needed
            const formattedEvents = events.map(event => {
                return {
                    title: event.title,
                    start: new Date(event.date).toISOString().split("T")[0], // Ensure correct format
                    url: `event-details.php?id=${event.id}`
                };
            });

            console.log("Formatted Events:", formattedEvents); // Debugging: Check formatted data

            calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth'  // ❌ Removed 'timeGridWeek' and 'timeGridDay'
                },
                events: formattedEvents
            });
            calendar.render(); // Ensure calendar renders after initialization
        })
        .catch(error => console.error("Error fetching events:", error));
});
