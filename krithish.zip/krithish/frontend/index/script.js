// Function to open a modal
function openModal(modalId) {
    document.getElementById(modalId).style.display = "block";
}

// Function to close a modal
function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none";
}

// Function to switch between login and signup modals
function switchModal(closeModalId, openModalId) {
    closeModal(closeModalId);
    openModal(openModalId);
}

// Close modal when clicking outside the content area
window.onclick = function(event) {
    let loginModal = document.getElementById('loginModal');
    let signupModal = document.getElementById('signupModal');

    if (event.target === loginModal) {
        closeModal('loginModal');
    }
    if (event.target === signupModal) {
        closeModal('signupModal');
    }
}

// Function to validate the login form
function validateLoginForm() {
    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;
    let loginError = document.getElementById('loginError');

    if (username === "" || password === "") {
        loginError.style.display = "block";
        loginError.textContent = "Please enter both username and password.";
        return false;
    }

    return true;
}

// Function to handle sign-up form submission
function handleSignup(event) {
    event.preventDefault(); // Prevent default form submission

    // Fetch correct input fields
    let fullName = document.querySelector("#signupModal input[name='fullName']").value;
    let username = document.querySelector("#signupModal input[name='username']").value;
    let phoneNumber = document.querySelector("#signupModal input[name='phoneNumber']").value;
    let email = document.querySelector("#signupModal input[name='email']").value;
    let password = document.querySelector("#signupModal input[name='password']").value;

    // Simple validation
    if (!fullName || !username || !phoneNumber || !email || !password) {
        alert("Please fill in all fields.");
        return;
    }

    // Send form data to signup.php
    fetch("signup.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `fullName=${encodeURIComponent(fullName)}&username=${encodeURIComponent(username)}&phoneNumber=${encodeURIComponent(phoneNumber)}&email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
    })
    .then(response => response.text())
    .then(data => {
        console.log("Server Response:", data); // Debugging output

        if (data.trim() === "success") { // Use trim() to remove spaces/newlines
            alert("Sign up successful! You can now log in.");
            closeModal('signupModal');
            openModal('loginModal');
        } else {
            alert("Sign up failed: " + data);
        }
    })
    .catch(error => console.error("Error:", error));
}
