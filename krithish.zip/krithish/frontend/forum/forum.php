<?php
include '../db.php';

// Fetch Events with Discussions
$sql = "SELECT e.id as event_id, e.title as event_name, 
               t.id as topic_id, t.title, t.content, 
               t.author, t.replies, t.created_at 
        FROM forum_topics t 
        JOIN `add-event` e ON t.event_id = e.id 
        ORDER BY t.created_at DESC";
$result = $conn->query($sql);

$topics = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $topics[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Forum | Moto Roadz</title>
    
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- External CSS -->
    <link rel="stylesheet" href="forum-style.css">
</head>
<body>

<!-- Main Content -->
<div class="main-content">
    <?php include '../sidebar.php';?>
    
    <header class="forum-header">
        <h1>Community Forum</h1>
        <button class="new-topic-btn" onclick="openPopup()">+ New Topic</button>
    </header>

    <!-- New Topic Modal -->
<div id="newTopicModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closePopup()">&times;</span>
        <h2>Create a New Topic</h2>
        
        <form action="add-topic.php" method="POST">
            <label for="event">Select Event:</label>
            <select id="event" name="event_id" required>
                <option value="">-- Select an Event --</option>
                <?php
                include '../db.php'; // Include database connection
                $event_query = $conn->query("SELECT id, title FROM `add-event`");
                while ($event = $event_query->fetch_assoc()) {
                    echo "<option value='{$event['id']}'>{$event['title']}</option>";
                }
                ?>
            </select>

            <label for="topic-title">Title:</label>
            <input type="text" id="topic-title" name="title" required>

            <label for="topic-content">Content:</label>
            <textarea id="topic-content" name="content" rows="5" required></textarea>

            <input type="hidden" name="author" value="JohnDoe"> <!-- Replace with dynamic user data -->

            <button type="submit" name="submit" class="submit-btn">Post Topic</button>
        </form>
    </div>
</div>


    <!-- Search Bar -->
    <div class="forum-controls">
        <input type="text" id="search-bar" placeholder="Search topics..." class="search-bar">
    </div>

    <!-- Forum Topics List -->
    <div class="forum-container">
        <?php
$grouped_topics = [];
foreach ($topics as $topic) {
    $grouped_topics[$topic['event_id']]['event_name'] = $topic['event_name'];
    $grouped_topics[$topic['event_id']]['topics'][] = $topic;
}
?>

<?php if (!empty($grouped_topics)) : ?>
    <?php foreach ($grouped_topics as $event_id => $event_data) : ?>
        <div class="event-section">
            <h2 class="event-title"><?php echo htmlspecialchars($event_data['event_name']); ?></h2>
            <?php foreach ($event_data['topics'] as $topic) : ?>
                <div class="topic-card">
                    <h3><?php echo htmlspecialchars($topic['title']); ?></h3>
                    <p><?php echo nl2br(htmlspecialchars($topic['content'])); ?></p>
                    <small>
                        <i class="fas fa-user"></i> <strong><?php echo htmlspecialchars($topic['author']); ?></strong> | 
                        <i class="fas fa-comments"></i> <?php echo $topic['replies']; ?> replies | 
                        <i class="fas fa-clock"></i> <?php echo date('F j, Y, g:i a', strtotime($topic['created_at'])); ?>
                    </small>
                    <button class="view-topic-btn" onclick="viewTopic(<?php echo $topic['topic_id']; ?>)">View Topic</button>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>
<?php else : ?>
    <p class="no-topics">No discussions available.</p>
<?php endif; ?>

    </div>
</div>

<script>
    function openPopup() {
        document.getElementById("newTopicModal").style.display = "block";
    }

    function closePopup() {
        document.getElementById("newTopicModal").style.display = "none";
    }

    window.onclick = function(event) {
        let modal = document.getElementById("newTopicModal");
        if (event.target === modal) {
            modal.style.display = "none";
        }
    }

    function viewTopic(id) {
        window.location.href = 'topic.php?id=' + id;
    }
</script>

</body>
</html>
