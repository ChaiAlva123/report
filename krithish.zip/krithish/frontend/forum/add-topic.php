<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $event_id = intval($_POST['event_id']); // Get selected event ID
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $author = $conn->real_escape_string($_POST['author']);

    // Validate that the event exists
    $event_check = $conn->query("SELECT id FROM `add-event` WHERE id = '$event_id'");
    if ($event_check->num_rows == 0) {
        die("Error: The selected event does not exist.");
    }

    // Insert the topic into the forum_topics table
    $sql = "INSERT INTO forum_topics (event_id, title, content, author, created_at) 
            VALUES ('$event_id', '$title', '$content', '$author', NOW())";

    if ($conn->query($sql) === TRUE) {
        header("Location: forum.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
