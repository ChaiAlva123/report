<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "moto-roadz";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$forum_count_query = $conn->query("SELECT COUNT(*) AS total FROM forum_topics");
$forum_count = $forum_count_query->fetch_assoc()['total'];

echo "<h3>$forum_count</h3>";
echo "<p>Forum Activity</p>";
?>
