<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "moto-roadz");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get image ID
$image_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$sql = "SELECT image FROM gallery WHERE id = $image_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    header("Content-Type: image/jpeg");
    echo $row['image']; // Output the image
} else {
    echo "Image not found!";
}

$conn->close();
?>
