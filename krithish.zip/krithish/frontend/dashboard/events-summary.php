<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "moto-roadz";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$event_count_query = $conn->query("SELECT COUNT(*) AS total FROM events");
$event_count = $event_count_query->fetch_assoc()['total'];

echo "<h3>Upcoming Events</h3>";
echo "<h3>$event_count</h3>";
?>
