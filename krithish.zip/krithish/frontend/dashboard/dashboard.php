<?php
include '../db.php';

// Fetch counts
$events_count = $conn->query("SELECT COUNT(*) AS total FROM `add-event`")->fetch_assoc()['total'];
$gallery_count = $conn->query("SELECT COUNT(*) AS total FROM gallery")->fetch_assoc()['total'];
$forum_count = $conn->query("SELECT COUNT(*) AS total FROM forum_topics")->fetch_assoc()['total'];

// Fetch latest event
$latest_event = $conn->query("SELECT id, title, description, date FROM `add-event` ORDER BY date ASC LIMIT 1")->fetch_assoc();

// Fetch latest gallery image
$latest_gallery = $conn->query("SELECT id FROM gallery ORDER BY id DESC LIMIT 1")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moto Roadz Dashboard</title>
    <link rel="stylesheet" href="../dashboard-styles.css">
</head>
<body>

    <div class="main-content">
        <?php include '../sidebar.php';?>
        <h1>Welcome</h1>

        <!-- Stats Boxes -->
        <div class="stats-container">
            <div class="stat-box">
                <h3>Upcoming Events</h3>
                <p><?php echo $events_count; ?></p>
                <a href="../event/event.php" class="view-more">View Calendar</a>
            </div>
            <div class="stat-box">
                <h3>Latest Gallery</h3>
                <p><?php echo $gallery_count; ?>+</p>
                <a href="../gallery/gallery.php" class="view-more">View Gallery</a>
            </div>
            <div class="stat-box">
                <h3>Forum Activity</h3>
                <p><?php echo $forum_count; ?></p>
                <a href="../forum/forum.php" class="view-more">View Topics</a>
            </div>
        </div>

        <!-- Upcoming Event Box -->
        <div class="event-box">
            <h2>Upcoming Events</h2>
            <?php if ($latest_event): ?>
            <div class="event-details">
                <h3><?php echo date("d M", strtotime($latest_event['date'])); ?></h3>
                <div>
                    <h4><?php echo $latest_event['title']; ?></h4>
                    <p><?php echo $latest_event['description']; ?></p>
                    <a href="register.php?event_id=<?php echo $latest_event['id']; ?>" class="register-btn">Register Now</a>
                </div>
            </div>
            <?php else: ?>
                <p>No upcoming events.</p>
            <?php endif; ?>
        </div>

        <!-- Quick Access -->
        <div class="quick-access">
            <div class="quick-box">
                <h3>Latest Gallery</h3>
                <?php if ($latest_gallery): ?>
                    <img src="image.php?id=<?php echo $latest_gallery['id']; ?>" class="gallery-img">
                <?php else: ?>
                    <p>No images available.</p>
                <?php endif; ?><br>
                <a href="../gallery/gallery.php">View All Photos</a>
            </div>
        </div>
    </div>
</body>
</html>
