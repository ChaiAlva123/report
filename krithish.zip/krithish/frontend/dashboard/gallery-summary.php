<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "moto-roadz";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$gallery_count_query = $conn->query("SELECT COUNT(*) AS total FROM gallery");
$gallery_count = $gallery_count_query->fetch_assoc()['total'];

echo "<h3>$gallery_count+</h3>";
echo "<p>Latest Gallery</p>";
?>
