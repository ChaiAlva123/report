<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "moto_roadz");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if image is uploaded
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["image"])) {
    $image = file_get_contents($_FILES["image"]["tmp_name"]);
    
    $stmt = $conn->prepare("INSERT INTO gallery (image) VALUES (?)");
    $stmt->bind_param("b", $image);
    
    if ($stmt->execute()) {
        echo "Image uploaded successfully!";
    } else {
        echo "Upload failed!";
    }
}

$conn->close();
?>
