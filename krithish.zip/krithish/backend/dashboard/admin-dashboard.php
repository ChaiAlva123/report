<?php
include '../db.php';

// Fetch upcoming events count
$eventQuery = "SELECT COUNT(*) AS total_events FROM events WHERE event_date >= CURDATE()";
$eventResult = $conn->query($eventQuery);
$eventCount = $eventResult->fetch_assoc()['total_events'] ?? 0;

// Fetch gallery images count
$galleryQuery = "SELECT COUNT(*) AS total_images FROM gallery";
$galleryResult = $conn->query($galleryQuery);
$galleryCount = $galleryResult->fetch_assoc()['total_images'] ?? 0;

// Fetch forum topics count
$forumQuery = "SELECT COUNT(*) AS total_topics FROM forum_topics";
$forumResult = $conn->query($forumQuery);
$forumCount = $forumResult->fetch_assoc()['total_topics'] ?? 0;

// Fetch recent system activities
$activityQuery = "SELECT activity_type, details, timestamp 
FROM system_activity 
ORDER BY timestamp DESC 
LIMIT 5;
";
$activityResult = $conn->query($activityQuery);
$activities = [];
while ($row = $activityResult->fetch_assoc()) {
    $activities[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - MOTO ROADZ</title>
    <link rel="stylesheet" href="../dashboard-styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <main class="main-content">
        <?php include"../sidebar.php";?>
        <header>
            <div class="header-content">
                <h1>Admin Dashboard</h1>
                <div class="admin-info">
                    <img src="https://via.placeholder.com/40" alt="Admin" class="admin-avatar">
                    <span class="admin-name">Admin</span>
                </div>
            </div>
        </header>

        <div class="dashboard-grid">
            <div class="card">
                <h3>Upcoming Events</h3>
                <p class="number"><?php echo $eventCount; ?></p>
            </div>
            <div class="card">
                <h3>Gallery Items</h3>
                <p class="number"><?php echo $galleryCount; ?></p>
            </div>
            <div class="card">
                <h3>Forum Topics</h3>
                <p class="number"><?php echo $forumCount; ?></p>
            </div>
        </div>

        <section class="recent-activity">
            <h2>System Activity</h2>
            <div class="activity-list">
                <?php foreach ($activities as $activity) : ?>
                    <div class="activity-item">
                        <div class="activity-icon"></div>
                        <div class="activity-details">
                            <h4><?php echo htmlspecialchars($activity['activity_type']); ?></h4>
                            <p><?php echo htmlspecialchars($activity['details']); ?></p>
                            <span class="time"><?php echo date("F d, Y H:i", strtotime($activity['timestamp'])); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($activities)) : ?>
                    <p>No recent activities.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>
</body>
</html>
