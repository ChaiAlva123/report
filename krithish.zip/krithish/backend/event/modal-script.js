document.addEventListener("DOMContentLoaded", function () {
    // Ensure modal is hidden on page load
    document.getElementById("addEventModal").style.display = "none";
});

function openModal(modalId) {
    document.getElementById(modalId).style.display = "block";
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none";
}

// Close modal when clicking outside
window.onclick = function(event) {
    let modal = document.getElementById('addEventModal');
    if (event.target == modal) {
        modal.style.display = "none";
    }
};

async function deleteEvent(eventId) {
    if (confirm('Are you sure you want to delete this event?')) {
        const response = await fetch(`delete_event.php?id=${eventId}`);
        if (response.ok) {
            alert('Event deleted successfully!');
            location.reload();
        } else {
            alert('Error deleting event.');
        }
    }
}

async function editEvent(id) {
    openModal('editEventModal');

    // Fetch event data
    try {
        const response = await fetch(`get_event.php?id=${id}`);
        const event = await response.json();

        if (!event.id) {
            alert("Event not found!");
            closeModal('editEventModal');
            return;
        }

        // Populate the edit modal fields
        document.getElementById("editEventId").value = event.id;
        document.getElementById("editEventTitle").value = event.title;
        document.getElementById("editEventDate").value = event.date;
        document.getElementById("editEventLocation").value = event.location;
        document.getElementById("editEventDescription").value = event.description;
    } catch (error) {
        console.error("Error fetching event details:", error);
        alert("Error loading event details.");
    }
}

// Handle form submission
document.getElementById("editEventForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    let formData = new FormData(this);

    try {
        const response = await fetch("update_event.php", {
            method: "POST",
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            alert("Event updated successfully!");
            closeModal('editEventModal');
            location.reload(); // Refresh to reflect changes
        } else {
            alert("Failed to update event.");
        }
    } catch (error) {
        console.error("Error updating event:", error);
        alert("An error occurred while updating.");
    }
});


async function registerEvent(eventId) {
    const response = await fetch(`register_event.php?id=${eventId}`);
    if (response.ok) {
        alert('Registration successful!');
    } else {
        alert('Error registering.');
    }
}

function viewRegistration(eventId) {
    window.location.href = `view_registration.php?id=${eventId}`;
}
