<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $date = $_POST['date'];
    $location = $_POST['location'];
    $description = $_POST['description'];

    $sql = "UPDATE `add-event` SET title=?, date=?, location=?, description=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $title, $date, $location, $description, $id);

    if ($stmt->execute()) {
        echo "Event updated successfully";
    } else {
        echo "Error updating event: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
