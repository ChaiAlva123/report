<?php
include '../db.php';
$sql = "SELECT * FROM `add-event` ORDER BY date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management - Admin</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <?php include '../sidebar.php'; ?>

    <main class="main-content">
        <header>
            <div class="header-content">
                <h1>Event Management</h1>
                <button class="add-btn" onclick="openModal('addEventModal')">
                    <i class="fas fa-plus"></i> Add New Event
                </button>
            </div>
        </header>

       <div class="events-grid" id="eventsGrid">
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="event-card">
            <div class="event-image">
    <?php 
    if (!empty($row['image'])) {
        // Convert LONGBLOB data to Base64 format
        $imageData = base64_encode($row['image']); 
        $imageSrc = 'data:image/jpeg;base64,' . $imageData; 
    ?>
        <img src="get_image.php?id=<?= $row['id']; ?>" alt="Event Image">

    <?php } else { ?>
        <img src="default-image.jpg" alt="No Image Available">
    <?php } ?>
</div>
            <div class="event-info">
                <h3><?= htmlspecialchars($row['title']); ?></h3>
                <p><i class="fas fa-calendar"></i> <?= htmlspecialchars($row['date']); ?></p>
                <p><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($row['location']); ?></p>
                <p> <?= htmlspecialchars($row['description']); ?></p>
                <div class="event-actions">
                    <button class="edit-btn" onclick="editEvent(<?= $row['id']; ?>)">Edit</button>
                    <button class="delete-btn" onclick="deleteEvent(<?= $row['id']; ?>)">Delete</button>
                    <button class="view-btn" onclick="viewRegistration(<?= $row['id']; ?>)">View Registration</button>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
</div>


    </main>

    <!-- Add Event Modal -->
    <div id="addEventModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('addEventModal')">&times;</span>
            <h2>Add New Event</h2>
            <form action="add_event.php" method="POST" enctype="multipart/form-data">
                <input type="text" name="title" placeholder="Event Title" required>
                <input type="date" name="date" required>
                <input type="text" name="location" placeholder="Location" required>
                <textarea name="description" placeholder="Event Description" required></textarea>
                <input type="file" name="image" accept="image/*" required>
                <button type="submit">Add Event</button>
            </form>
        </div>
    </div>

    <!-- Edit Event Modal -->
<div id="editEventModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closeModal('editEventModal')">&times;</span>
        <h2>Edit Event</h2>
        <form id="editEventForm">
            <input type="hidden" name="id" id="editEventId">
            <input type="text" name="title" id="editEventTitle" placeholder="Event Title" required>
            <input type="date" name="date" id="editEventDate" required>
            <input type="text" name="location" id="editEventLocation" placeholder="Location" required>
            <textarea name="description" id="editEventDescription" placeholder="Event Description" required></textarea>
            <input type="file" name="image" id="editEventImage" accept="image/*">
            <button type="submit">Update Event</button>
        </form>
    </div>
</div>


    <?php $conn->close(); ?>

    <script src="modal-script.js"></script> <!-- External JS -->
</body>
</html>
