<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $date = $_POST['date'];
    $location = $_POST['location'];
    $description = $_POST['description'];

    // Check if an image was uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $imageData = file_get_contents($_FILES['image']['tmp_name']); // Read file content
        $imageData = addslashes($imageData); // Escape special characters
    } else {
        die("Error: No image uploaded or file error.");
    }

    // Insert into database
    $sql = "INSERT INTO `add-event` (title, date, location, description, image) VALUES ('$title', '$date', '$location', '$description', '$imageData')";

    if ($conn->query($sql) === TRUE) {
        <?php
header("Location: event.php");
exit();
?>
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}
?>
