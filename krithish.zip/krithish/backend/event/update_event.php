<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $title = $_POST['title'];
    $date = $_POST['date'];
    $location = $_POST['location'];
    $description = $_POST['description'];

    // Handle image upload if a new one is provided
    if (!empty($_FILES['image']['name'])) {
        $imageData = file_get_contents($_FILES['image']['tmp_name']);
        $sql = "UPDATE `add-event` SET title=?, date=?, location=?, description=?, image=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssbi", $title, $date, $location, $description, $imageData, $id);
    } else {
        $sql = "UPDATE `add-event` SET title=?, date=?, location=?, description=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $title, $date, $location, $description, $id);
    }

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false]);
    }

    $stmt->close();
}

$conn->close();
?>
