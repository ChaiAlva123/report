<?php
include '../db.php';

if (isset($_GET['id'])) {
    $eventId = intval($_GET['id']);
    $sql = "SELECT * FROM `event-registrations` WHERE event_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>View Registrations</title>
        <link rel="stylesheet" href="styles.css"> <!-- External CSS file -->
    </head>
    <body>
        <h2>Registrations for Event</h2>
        <table border="2 ">
            <tr>
                <th>ID</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Registered At</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= htmlspecialchars($row['user_name']); ?></td>
                    <td><?= htmlspecialchars($row['email']); ?></td>
                    <td><?= $row['created_at']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
        <button onclick="window.history.back()">Go Back</button>
    </body>
    </html>

    <?php
    $stmt->close();
    $conn->close();
}
?>
