<?php
include '../db.php';

if (isset($_GET['id'])) {
    $eventId = intval($_GET['id']);
    $sql = "INSERT INTO event_registrations (event_id) VALUES (?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $eventId);

    if ($stmt->execute()) {
        echo "Registration successful";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
