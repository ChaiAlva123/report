<?php
include '../db.php';

if (isset($_GET['id'])) {
    $eventId = intval($_GET['id']); 
    $sql = "DELETE FROM `add-event` WHERE id = $eventId";

    if ($conn->query($sql) === TRUE) {
        echo "Event deleted successfully";
    } else {
        echo "Error deleting event: " . $conn->error;
    }
    $conn->close();
}
?>
