<?php
include '../db.php';

// Fetch Event Reports
$event_reports = $conn->query("SELECT * FROM event_reports ORDER BY report_date DESC");

// Fetch User Feedback
$user_feedback = $conn->query("SELECT * FROM user_feedback ORDER BY feedback_date DESC");

// Calculate Average Rating
$rating_result = $conn->query("SELECT AVG(rating) AS avg_rating FROM user_feedback");
$avg_rating = $rating_result->fetch_assoc()['avg_rating'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Feedback</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- Main Content -->
<div class="main-container">
        <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>
    <div class="content">
        <!-- Header Section -->
        <div class="header">
            <h1>Reports & Feedback</h1>
            <select id="report-filter">
                <option value="all">All Reports</option>
                <option value="event">Event Reports</option>
                <option value="user">User Reports</option>
                <option value="feedback">General Feedback</option>
            </select>
        </div>

        <!-- Event Reports -->
        <h2>Event Reports</h2>
        <div class="report-container">
            <?php while ($row = $event_reports->fetch_assoc()): ?>
                <div class="report-card">
                    <span class="tag event">Event Report</span>
                    <h3><?= htmlspecialchars($row['event_name']) ?></h3>
                    <p><?= htmlspecialchars($row['description']) ?></p>
                    <p class="report-meta">Reported by: <?= htmlspecialchars($row['reported_by']) ?> | Priority: <?= htmlspecialchars($row['priority']) ?></p>
                    <div class="report-actions">
                        <button class="view-btn">View Details</button>
                        <button class="resolve-btn">Mark Resolved</button>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- User Feedback -->
        <h2>User Feedback</h2>
        <div class="report-container">
            <?php while ($row = $user_feedback->fetch_assoc()): ?>
                <div class="feedback-card">
                    <span class="tag feedback">Positive Feedback</span>
                    <p><?= htmlspecialchars($row['feedback_text']) ?></p>
                    <p class="feedback-rating">⭐ <?= number_format($row['rating'], 1) ?></p>
                    <div class="feedback-actions">
                        <button class="respond-btn">Respond</button>
                        <button class="archive-btn">Archive</button>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- Feedback Analytics -->
        <h2>Feedback Analytics</h2>
        <div class="analytics-card">
            <h3>Average Rating</h3>
            <p class="avg-rating"><?= number_format($avg_rating, 1) ?></p>
            <p class="rating-change">📈 +0.3</p>
        </div>
    </div>
</div>

</body>
</html>
