<?php
session_start();
session_destroy();
header("Location:../moto/index/index.html");
exit();
?>
