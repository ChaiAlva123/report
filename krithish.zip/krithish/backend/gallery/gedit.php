<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];

    if (!empty($_FILES['image']['tmp_name'])) {
        // New image uploaded
        $imageData = file_get_contents($_FILES['image']['tmp_name']);
        $stmt = $conn->prepare("UPDATE gallery SET event_name = ?, event_date = ?, image = ? WHERE id = ?");
        $stmt->bind_param("sssi", $event_name, $event_date, $imageData, $id);
    } else {
        // No new image uploaded, keep existing image
        $stmt = $conn->prepare("UPDATE gallery SET event_name = ?, event_date = ? WHERE id = ?");
        $stmt->bind_param("ssi", $event_name, $event_date, $id);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Image updated successfully!'); window.location.href='gallery.php';</script>";
    } else {
        echo "<script>alert('Error updating image.');</script>";
    }

    $stmt->close();
}

$conn->close();
?>
