<?php
include '../db.php'; // Database connection

// Fetch images from database
$sql = "SELECT * FROM gallery ORDER BY event_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery Management - Admin</title>
    <link rel="stylesheet" href="gstyles.css">
</head>
<body>

<div class="main-container">
    <!-- Sidebar -->
    <?php include '../sidebar.php'; ?>

    <!-- Main Content -->
    <div class="content">
        <h1>Gallery Management</h1>
        <button class="open-modal-btn" onclick="openModal('uploadModal')">Upload Image</button>

        <!-- Gallery Grid -->
        <div class="gallery-grid">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="gallery-card">
                    <img src="data:image/jpeg;base64,<?= base64_encode($row['image']); ?>" alt="Event Image">
                    <div class="gallery-details">
                        <h4><?= htmlspecialchars($row['event_name']); ?></h4>
                        <p><?= htmlspecialchars($row['event_date']); ?></p>
                        <div class="card-actions">
                            <button class="edit-btn" onclick="openEditModal(<?= $row['id']; ?>, '<?= htmlspecialchars($row['event_name']); ?>', '<?= $row['event_date']; ?>')">Edit</button>
                            <button class="delete-btn" onclick="deleteImage(<?= $row['id']; ?>)">Delete</button>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<!-- Upload Image Modal -->
<div id="uploadModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('uploadModal')">&times;</span>
        <h2>Upload Image</h2>
        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <input type="text" name="event_name" placeholder="Event Name" required>
            <input type="date" name="event_date" required>
            <input type="file" name="image" accept="image/*" required>
            <button type="submit">Upload</button>
        </form>
    </div>
</div>

<!-- Edit Image Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('editModal')">&times;</span>
        <h2>Edit Image</h2>
        <form action="gedit.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" id="edit-id">
            <input type="text" name="event_name" id="edit-event-name" placeholder="Event Name" required>
            <input type="date" name="event_date" id="edit-event-date" required>
            <input type="file" name="image" accept="image/*">
            <button type="submit">Update</button>
        </form>
    </div>
</div>

<script>
    // Open and close modals
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Open Edit Image Modal with pre-filled data
function openEditModal(id, name, date) {
    document.getElementById("edit-id").value = id;
    document.getElementById("edit-event-name").value = name;
    document.getElementById("edit-event-date").value = date;
    openModal('editModal');
}

// Custom delete confirmation pop-up
function deleteImage(id) {
    const confirmBox = document.createElement("div");
    confirmBox.className = "custom-popup";
    confirmBox.innerHTML = `
        <div class="popup-content">
            <p>Are you sure you want to delete this image?</p>
            <button onclick="confirmDelete(${id})">Yes</button>
            <button onclick="closePopup()">No</button>
        </div>`;
    document.body.appendChild(confirmBox);
}

function confirmDelete(id) {
    window.location.href = "gdelete.php?id=" + id;
}

function closePopup() {
    document.querySelector(".custom-popup").remove();
}

</script>

</body>
</html>
