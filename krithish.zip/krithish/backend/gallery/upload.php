<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        // Read image file content
        $imageData = file_get_contents($_FILES['image']['tmp_name']);

        // Prepare the SQL statement
        $stmt = $conn->prepare("INSERT INTO gallery (event_name, event_date, image) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $event_name, $event_date, $imageData);

        if ($stmt->execute()) {
            echo "<script>alert('Image uploaded successfully!'); window.location.href='gallery.php';</script>";
        } else {
            echo "<script>alert('Error uploading image.');</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Invalid image file.');</script>";
    }
}

$conn->close();
?>
