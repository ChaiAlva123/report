<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MOTO ROADZ Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        /* Sidebar Styles */
        .sidebar {
    width: 250px; /* Adjust sidebar width */
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    background: #111; /* Dark sidebar */
    color: white;
    padding: 20px;
}

        .sidebar .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar .logo img {
            width: 100px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 15px;
            text-align: left;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
        }

        .sidebar ul li a:hover {
            background-color: #444;
            border-radius: 5px;
            transition: 0.3s;
        }

        .sidebar ul li a.active {
            background-color: #007bff;
            border-radius: 5px;
        }

    </style>
</head>
<body>

    <nav class="sidebar">
        <div class="logo">
            <img src="logo.png" alt="MOTO ROADZ Logo" class="animate-logo" width="150px" height="auto">
            <span>MOTO ROADZ</span>
        </div>
        <ul class="nav-links">
            <li><a href="../dashboard/admin-dashboard.php"><i class="fas fa-home"></i>Dashboard</a></li>
            <li><a href="../event/event.php"><i class="fas fa-calendar-alt"></i>Events</a></li>
            <li><a href="../gallery/gallery.php"><i class="fas fa-images"></i>Gallery</a></li>
            <li><a href="../forum/forum.php"><i class="fas fa-comments"></i>Forum</a></li>
            <li><a href="../report/report.php"><i class="fas fa-chart-bar"></i>Reports</a></li>
            <li class="logout"><a href="../logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
        </ul>
    </nav>

</body>
</html>
