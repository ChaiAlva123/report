<?php
include '../db.php'; // Adjusted path for proper inclusion

$sql = "SELECT e.id AS event_id, e.title AS event_name, 
               t.id AS topic_id, t.title, t.content, 
               t.author, t.replies, t.created_at 
        FROM forum_topics t 
        JOIN events e ON t.event_id = e.id 
        ORDER BY t.created_at DESC";
$result = $conn->query($sql);

$topics = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $topics[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Forum | Moto Roadz</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<!-- Include Sidebar -->
<?php include '../sidebar.php'; ?>

<!-- Main Content -->
<div class="main-content">
    <header>
        <h1>Community Forum</h1>
    </header>

    <!-- Forum Controls -->
    <div class="forum-controls">
        <input type="text" id="search-bar" placeholder="Search topics..." class="search-bar">
    </div>

    <!-- Forum Topics List -->
    <div class="forum-container">
        <?php if (!empty($topics)) : ?>
            <?php foreach ($topics as $topic) : ?>
                <div class="topic-card">
                    <h3><?php echo htmlspecialchars($topic['title']); ?></h3>
                    <p><?php echo nl2br(htmlspecialchars($topic['content'])); ?></p>
                    <small>
                        <strong><?php echo htmlspecialchars($topic['author']); ?></strong> | 
                        <?php echo $topic['replies']; ?> replies | 
                        <?php echo date('F j, Y, g:i a', strtotime($topic['created_at'])); ?>
                    </small>
                    <button class="view-topic-btn" onclick="viewTopic(<?php echo $topic['topic_id']; ?>)">View Topic</button>
                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <p>No discussions available.</p>
        <?php endif; ?>
    </div>
</div>

<script>
    function viewTopic(id) {
        window.location.href = 'topic.php?id=' + id;
    }
</script>

</body>
</html>
